import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        sand: "#F5F1EA", sandDark: "#EAE3D6",
        ink: "#2B2620", inkSoft: "#6B6155",
        moss: "#7A8B6F", mossDark: "#5F6E56",
        cream: "#FDFBF7"
      },
      fontFamily: { display: ["var(--font-display)"], body: ["var(--font-body)"] }
    }
  },
  plugins: []
};
export default config;
