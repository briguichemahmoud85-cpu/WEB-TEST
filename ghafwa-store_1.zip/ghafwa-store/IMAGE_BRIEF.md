# IMAGE_BRIEF — غفوة (Ghafwa)

## Style bible (مشترك في كل الصور)
- المنتج: وسادة رقبة طبية ميموري فوم بتصميم "قرن الثور"، غطاء Ice Silk رمادي فاتح
- الخلفية: استوديو بيج دافئ، إضاءة ناعمة منتشرة، ظل خفيف
- المرجعية: كل الصور (عدا الـhero) تمرَّر لها صورة الـhero كمرجع بصيغة
  "the SAME ox-horn pillow shown in the reference image..."
- النموذج: nano_banana_pro (2 كريديت/صورة)

## الصور المولّدة (كلها مكتملة ✓)

| المفتاح في images.ts | الاستخدام | Job ID | الرابط |
|---|---|---|---|
| heroMain | Hero رئيسية | 348bcbc1-f39b-4b17-b41e-e62416efc966 | hf_20260725_234218_….png |
| sideProfile | ميزة 1: التصميم | 5f227ec7-fc5b-4566-9aaa-d16056b26c48 | hf_20260725_234245_….png |
| coverUnzipped | ميزة 3: الغطاء | 8d168f4f-1fed-4539-8710-c587e80f671e | hf_20260725_234250_….png |
| lifestyleSleep | قسم المشكلة | 9231a3bc-9305-43f3-b4bb-a1128072fea2 | hf_20260725_234256_….png |
| slowRebound | ميزة 2: الفوم | 9b485e4a-a7e8-4916-9cb5-0312bec8f1f8 | hf_20260725_234302_….png |

CDN base: `https://d8j0ntlcm91z4.cloudfront.net/user_3GTezMGyj0Z2ofyI6hBtyOvs998/`

## تنزيل الصور محليًا للإنتاج (من جهازك — الشبكة هنا كانت مقفولة)

```bash
CDN="https://d8j0ntlcm91z4.cloudfront.net/user_3GTezMGyj0Z2ofyI6hBtyOvs998"
curl -o public/images/hero-main.png       "$CDN/hf_20260725_234218_348bcbc1-f39b-4b17-b41e-e62416efc966.png"
curl -o public/images/side-profile.png    "$CDN/hf_20260725_234245_5f227ec7-fc5b-4566-9aaa-d16056b26c48.png"
curl -o public/images/cover-unzipped.png  "$CDN/hf_20260725_234250_8d168f4f-1fed-4539-8710-c587e80f671e.png"
curl -o public/images/lifestyle-sleep.png "$CDN/hf_20260725_234256_9231a3bc-9305-43f3-b4bb-a1128072fea2.png"
curl -o public/images/slow-rebound.png    "$CDN/hf_20260725_234302_9b485e4a-a7e8-4916-9cb5-0312bec8f1f8.png"
```
ثم حدّث `lib/images.ts` للمسارات المحلية `/images/<name>.png`.

## صور إضافية مقترحة (لو حبيت تكمّل السِت)
- packaging flat lay (صندوق البراند + الوسادة)
- lifestyle ثاني: رجل نائم على الظهر (لتغطية الجمهورين)
- og-image بمقاس 1200×630 لمشاركات السوشيال
- فيديو hero قصير (kling3_0_turbo، ~7.5 كريديت): دوران بطيء للوسادة

## أصول الإعلانات + الفيديو (مكتملة ✓)

```bash
curl -o ads/ad-night-moody.png   "$CDN/hf_20260725_235231_54e6bf8e-48c0-4148-96ab-364ada36069f.png"
curl -o ads/ad-before-after.png  "$CDN/hf_20260725_235237_e3aad3a0-2c0d-4b5c-90fb-12ec9d23249a.png"
curl -o ads/hero-video.mp4       "$CDN/hf_20260725_235225_d7444d19-78f7-4c1d-98b4-289922762bf3.mp4"
```
