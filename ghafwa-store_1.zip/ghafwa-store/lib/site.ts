// كل ثوابت البراند والسعر والمواصفات في مكان واحد.
// المواصفات المؤكدة مصدرها صفحة المورّد على Alibaba (منتج 1600896121787).
// أي قيمة غير مؤكدة تبقى {{PLACEHOLDER}} لحين تأكيد المورّد.

export const BRAND = {
  name: "غفوة",
  nameLatin: "Ghafwa",
  positioning: "وسادة طبية تُريح رقبتك من أول ليلة",
  market: "SA",
  locale: "ar-SA",
} as const;

export const PRICING = {
  price: 149,
  compareAt: 249,
  currency: "ر.س",
  get discountPct() {
    return Math.round((1 - this.price / this.compareAt) * 100);
  },
  codNote: "الدفع عند الاستلام — افحص المنتج قبل ما تدفع",
} as const;

// [observed] من صفحة المورّد — مؤكدة
export const SPECS = {
  shape: "تصميم قرن الثور (Ox Horn Contour)",
  filling: "ميموري فوم بطيء الارتداد",
  size: "620 × 350 × 135 مم",
  weight: "1300 جرام",
  cover: "غطاء Ice Silk بارد الملمس — قابل للفك بسحّاب",
  certification: "OEKO-TEX STANDARD 100",
  functions: "دعم فقرات الرقبة · مضادة للشخير · مضادة للكهرباء الساكنة",
  // غير مؤكد من المورّد بعد:
  warrantyMonths: "{{PLACEHOLDER_WARRANTY}}",
  foamDensity: "{{PLACEHOLDER_DENSITY}}",
} as const;

export const SHIPPING = {
  regions: "جميع مدن المملكة",
  eta: "2 إلى 4 أيام عمل",
  cod: true,
} as const;

export const ANCHORS = {
  hero: "hero",
  problem: "problem",
  features: "features",
  specs: "specs",
  order: "order",
  faq: "faq",
} as const;
