// كل النصوص الظاهرة للمستخدم — عربية سعودية، مكتوبة أصلًا مش مترجمة.
// قاعدة صدق: لا تقييمات مختلقة — قسم التقييمات {{REVIEW_PLACEHOLDER}} لحين وجود تقييمات حقيقية.

import { IMAGES } from "./images";
import { PRICING, SPECS, SHIPPING } from "./site";

export const HERO = {
  eyebrow: "وسادة غفوة الطبية",
  headline: "صحّ من النوم بدون ألم رقبة",
  subhead:
    "تصميم قرن الثور يحتضن انحناءة رقبتك الطبيعية، وميموري فوم بطيء الارتداد يوزّع الضغط — عشان تنام وتصحى مرتاح.",
  cta: "اطلب الآن — الدفع عند الاستلام",
  image: IMAGES.heroMain,
} as const;

export const TRUST_BADGES = [
  { icon: "💵", label: "الدفع عند الاستلام" },
  { icon: "📦", label: "افحص قبل ما تدفع" },
  { icon: "🚚", label: `توصيل ${SHIPPING.eta}` },
  { icon: "🧵", label: "شهادة OEKO-TEX 100" },
] as const;

export const PROBLEM = {
  title: "الوسادة العادية هي سبب وجع رقبتك غالبًا",
  items: [
    "ارتفاع غير مناسب يترك رقبتك معلّقة أو مضغوطة طول الليل",
    "حشو يهبط بعد أسابيع ويفقد أي دعم",
    "حرارة وتعرّق مع أقمشة تحبس الحرارة — خصوصًا في صيفنا",
    "صداع الصباح وتنميل الكتف اللي تحس فيه أول ما تصحى",
  ],
  image: IMAGES.lifestyleSleep,
} as const;

export const FEATURES = {
  title: "ليش تصميم غفوة مختلف؟",
  items: [
    {
      id: "contour",
      nav: "تصميم قرن الثور",
      title: "انحناءة مدروسة لفقرات رقبتك",
      body: "الشكل المقوّس يرفع الرقبة ويسند الرأس في وضعه الطبيعي — سواء تنام على ظهرك أو على جنبك.",
      image: IMAGES.sideProfile,
    },
    {
      id: "foam",
      nav: "ميموري فوم",
      title: "ارتداد بطيء يوزّع الضغط",
      body: "الفوم يتشكّل على رأسك ورقبتك بالضبط ثم يرجع لشكله — بدون ما يهبط زي الحشو العادي.",
      image: IMAGES.slowRebound,
    },
    {
      id: "cover",
      nav: "غطاء بارد",
      title: "قماش Ice Silk بارد الملمس وقابل للغسيل",
      body: "غطاء خارجي بسحّاب ينفك ويُغسل بسهولة، بملمس بارد يناسب حرارة أجوائنا.",
      image: IMAGES.coverUnzipped,
    },
  ],
} as const;

export const SPECS_SECTION = {
  title: "المواصفات — بالأرقام",
  rows: [
    { label: "الشكل", value: SPECS.shape },
    { label: "الحشو", value: SPECS.filling },
    { label: "المقاس", value: SPECS.size },
    { label: "الوزن", value: SPECS.weight },
    { label: "الغطاء", value: SPECS.cover },
    { label: "الشهادة", value: SPECS.certification },
    { label: "الوظائف", value: SPECS.functions },
  ],
} as const;

export const OFFER = {
  title: "اطلب وسادة غفوة الآن",
  priceLine: `${PRICING.price} ${PRICING.currency}`,
  compareLine: `${PRICING.compareAt} ${PRICING.currency}`,
  savings: `وفّر ${PRICING.discountPct}%`,
  codNote: PRICING.codNote,
  shippingNote: `${SHIPPING.regions} · ${SHIPPING.eta}`,
  formTitle: "عبّي بياناتك ونوصلك",
  fields: {
    name: "الاسم الكامل",
    phone: "رقم الجوال",
    city: "المدينة",
    address: "العنوان (الحي والشارع)",
  },
  submit: "أكّد الطلب — ادفع عند الاستلام",
  successTitle: "تم استلام طلبك ✓",
  successBody: "بنتواصل معك على الجوال لتأكيد الطلب قبل الشحن.",
} as const;

export const FAQ = {
  title: "أسئلة شائعة",
  items: [
    {
      q: "هل تناسب النوم على الجنب؟",
      a: "نعم — ارتفاع الجانبين مصمم للنوم الجانبي، والانخفاض الأوسط للنوم على الظهر.",
    },
    {
      q: "كم أحتاج حتى أتعوّد عليها؟",
      a: "أغلب المستخدمين لوسائد الميموري فوم يتأقلمون خلال 3 إلى 7 ليالٍ، لأن وضعية الرقبة الصحيحة تكون جديدة على العضلات.",
    },
    {
      q: "هل الغطاء يُغسل؟",
      a: "نعم، الغطاء الخارجي ينفك بسحّاب ويُغسل. الفوم الداخلي لا يُغسل بالماء.",
    },
    {
      q: "هل أدفع قبل الاستلام؟",
      a: "لا — الدفع كامل عند الاستلام، وتقدر تفحص المنتج قدام المندوب قبل الدفع.",
    },
  ],
} as const;

// {{REVIEW_PLACEHOLDER}} — لا نعرض تقييمات إلا الحقيقية بعد أول مبيعات.
export const REVIEWS_PLACEHOLDER = {
  note: "قسم التقييمات يُفعَّل بعد جمع تقييمات حقيقية من عملاء فعليين.",
} as const;

export const FOOTER = {
  line: "غفوة — نوم أعمق، صباح أخف.",
  disclaimer:
    "الصور توضيحية مولّدة بتقنية الذكاء الاصطناعي بناءً على مواصفات المنتج الفعلية من المورّد.",
} as const;
