// خريطة الصور المركزية — كل المكونات تقرأ منها.
// حاليًا الروابط على CDN التوليد (Higgsfield). للإنتاج: نزّل الملفات إلى
// public/images/ بنفس الأسماء الدلالية (أوامر curl جاهزة في IMAGE_BRIEF.md).

const CDN = "https://d8j0ntlcm91z4.cloudfront.net/user_3GTezMGyj0Z2ofyI6hBtyOvs998";

export const IMAGES = {
  heroMain: `${CDN}/hf_20260725_234218_348bcbc1-f39b-4b17-b41e-e62416efc966.png`,
  sideProfile: `${CDN}/hf_20260725_234245_5f227ec7-fc5b-4566-9aaa-d16056b26c48.png`,
  coverUnzipped: `${CDN}/hf_20260725_234250_8d168f4f-1fed-4539-8710-c587e80f671e.png`,
  lifestyleSleep: `${CDN}/hf_20260725_234256_9231a3bc-9305-43f3-b4bb-a1128072fea2.png`,
  slowRebound: `${CDN}/hf_20260725_234302_9b485e4a-a7e8-4916-9cb5-0312bec8f1f8.png`,
  // كرييتيف إعلانات Meta (مش مستخدمة في الموقع — للأرشفة والحملات)
  adNightMoody: `${CDN}/hf_20260725_235231_54e6bf8e-48c0-4148-96ab-364ada36069f.png`,
  adBeforeAfter: `${CDN}/hf_20260725_235237_e3aad3a0-2c0d-4b5c-90fb-12ec9d23249a.png`,
} as const;

// فيديو الـHero — يُملأ بعد اكتمال التوليد (job d7444d19-…)
export const HERO_VIDEO: string | null =
  `${CDN}/hf_20260725_235225_d7444d19-78f7-4c1d-98b4-289922762bf3.mp4`;

export type ImageKey = keyof typeof IMAGES;
