import Image from "next/image";
import { FEATURES } from "@/lib/content";
import { ANCHORS } from "@/lib/site";

export default function Features() {
  return (
    <section id={ANCHORS.features} className="bg-sand py-12">
      <div className="container-g">
        <h2 className="heading-lg mb-8 text-center">{FEATURES.title}</h2>
        <div className="space-y-10">
          {FEATURES.items.map((f, i) => (
            <div key={f.id} className="card">
              <p className="eyebrow mb-1">{String(i + 1).padStart(2, "0")} · {f.nav}</p>
              <h3 className="font-display font-bold text-xl mb-2">{f.title}</h3>
              <p className="text-inkSoft mb-4">{f.body}</p>
              <div className="relative w-full aspect-square max-w-sm mx-auto rounded-xl overflow-hidden">
                <Image src={f.image} alt={f.title} fill className="object-cover" sizes="384px" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
