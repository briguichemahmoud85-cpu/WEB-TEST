import Image from "next/image";
import { HERO } from "@/lib/content";
import { ANCHORS, PRICING } from "@/lib/site";
import { HERO_VIDEO } from "@/lib/images";

export default function Hero() {
  return (
    <section id={ANCHORS.hero} className="bg-sand pt-12 pb-10">
      <div className="container-g text-center">
        <p className="eyebrow mb-3">{HERO.eyebrow}</p>
        <h1 className="heading-xl mb-4">{HERO.headline}</h1>
        <p className="text-inkSoft mb-7 max-w-md mx-auto">{HERO.subhead}</p>
        <div className="relative w-full aspect-[4/3] max-w-lg mx-auto mb-7 rounded-2xl overflow-hidden">
          {HERO_VIDEO ? (
            <video
              className="absolute inset-0 h-full w-full object-cover"
              src={HERO_VIDEO}
              poster={HERO.image}
              autoPlay
              loop
              muted
              playsInline
            />
          ) : (
            <Image src={HERO.image} alt="وسادة غفوة الطبية" fill priority className="object-cover" sizes="(max-width: 768px) 100vw, 512px" />
          )}
        </div>
        <div className="flex items-baseline justify-center gap-3 mb-4">
          <span className="font-display font-extrabold text-3xl text-mossDark">{PRICING.price} {PRICING.currency}</span>
          <span className="text-inkSoft line-through">{PRICING.compareAt} {PRICING.currency}</span>
        </div>
        <a href={`#${ANCHORS.order}`} className="btn-primary">{HERO.cta}</a>
        <p className="text-inkSoft text-sm mt-3">{PRICING.codNote}</p>
      </div>
    </section>
  );
}
