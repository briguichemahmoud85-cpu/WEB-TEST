import { SPECS_SECTION } from "@/lib/content";
import { ANCHORS } from "@/lib/site";

export default function Specs() {
  return (
    <section id={ANCHORS.specs} className="py-12">
      <div className="container-g">
        <h2 className="heading-lg mb-6 text-center">{SPECS_SECTION.title}</h2>
        <div className="card divide-y divide-sandDark">
          {SPECS_SECTION.rows.map((r) => (
            <div key={r.label} className="flex justify-between gap-4 py-3 text-sm">
              <span className="text-inkSoft shrink-0">{r.label}</span>
              <span className="font-medium text-left">{r.value}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
