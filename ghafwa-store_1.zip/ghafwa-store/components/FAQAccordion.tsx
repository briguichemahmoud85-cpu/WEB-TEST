"use client";
import { useState } from "react";
import { FAQ } from "@/lib/content";
import { ANCHORS } from "@/lib/site";

export default function FAQAccordion() {
  const [open, setOpen] = useState<string | null>(null);
  return (
    <section id={ANCHORS.faq} className="py-12">
      <div className="container-g">
        <h2 className="heading-lg mb-6 text-center">{FAQ.title}</h2>
        <div className="space-y-2">
          {FAQ.items.map((item) => {
            const isOpen = open === item.q;
            return (
              <div key={item.q} className="card !p-0 overflow-hidden">
                <button
                  className="w-full flex justify-between items-center gap-3 p-4 text-right font-display font-bold"
                  onClick={() => setOpen(isOpen ? null : item.q)}
                >
                  <span>{item.q}</span>
                  <span className="text-mossDark text-xl shrink-0">{isOpen ? "−" : "+"}</span>
                </button>
                {isOpen && <p className="px-4 pb-4 text-inkSoft text-sm">{item.a}</p>}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
