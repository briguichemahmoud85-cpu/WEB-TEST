import { TRUST_BADGES } from "@/lib/content";

export default function TrustBadges() {
  return (
    <section className="bg-cream border-y border-sandDark py-5">
      <div className="container-g grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        {TRUST_BADGES.map((b) => (
          <div key={b.label} className="flex flex-col items-center gap-1">
            <span className="text-2xl">{b.icon}</span>
            <span className="text-sm text-inkSoft font-medium">{b.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
