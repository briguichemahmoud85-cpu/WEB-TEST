import { FOOTER } from "@/lib/content";
import { BRAND } from "@/lib/site";

export default function Footer() {
  return (
    <footer className="bg-ink text-cream/70 py-8 text-center text-sm">
      <div className="container-g space-y-2">
        <p className="font-display font-bold text-cream">{BRAND.name} | {BRAND.nameLatin}</p>
        <p>{FOOTER.line}</p>
        <p className="text-xs text-cream/40 max-w-md mx-auto">{FOOTER.disclaimer}</p>
      </div>
    </footer>
  );
}
