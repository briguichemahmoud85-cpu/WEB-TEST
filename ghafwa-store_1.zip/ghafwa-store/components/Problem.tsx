import Image from "next/image";
import { PROBLEM } from "@/lib/content";
import { ANCHORS } from "@/lib/site";

export default function Problem() {
  return (
    <section id={ANCHORS.problem} className="py-12">
      <div className="container-g">
        <h2 className="heading-lg mb-6 text-center">{PROBLEM.title}</h2>
        <ul className="space-y-3 mb-7">
          {PROBLEM.items.map((item) => (
            <li key={item} className="flex gap-3 text-inkSoft">
              <span className="text-mossDark font-bold shrink-0">✕</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
        <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden">
          <Image src={PROBLEM.image} alt="نوم مريح على وسادة غفوة" fill className="object-cover" sizes="(max-width: 768px) 100vw, 672px" />
        </div>
      </div>
    </section>
  );
}
