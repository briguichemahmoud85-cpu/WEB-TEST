"use client";
import { useState } from "react";
import { OFFER } from "@/lib/content";
import { ANCHORS } from "@/lib/site";

type FormState = { name: string; phone: string; city: string; address: string };
const EMPTY: FormState = { name: "", phone: "", city: "", address: "" };

export default function OfferCard() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");

  const set = (k: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit() {
    if (!form.name || !form.phone || !form.city || !form.address) return;
    setStatus("sending");
    try {
      const res = await fetch("/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("failed");
      setStatus("done");
    } catch {
      setStatus("error");
    }
  }

  return (
    <section id={ANCHORS.order} className="bg-sand py-12">
      <div className="container-g max-w-md">
        <h2 className="heading-lg mb-2 text-center">{OFFER.title}</h2>
        <div className="flex items-baseline justify-center gap-3 mb-1">
          <span className="font-display font-extrabold text-3xl text-mossDark">{OFFER.priceLine}</span>
          <span className="text-inkSoft line-through">{OFFER.compareLine}</span>
          <span className="text-mossDark font-bold text-sm">{OFFER.savings}</span>
        </div>
        <p className="text-center text-inkSoft text-sm mb-6">{OFFER.shippingNote}</p>

        {status === "done" ? (
          <div className="card text-center">
            <p className="font-display font-bold text-xl mb-1">{OFFER.successTitle}</p>
            <p className="text-inkSoft text-sm">{OFFER.successBody}</p>
          </div>
        ) : (
          <div className="card space-y-3">
            <p className="font-display font-bold">{OFFER.formTitle}</p>
            <input className="w-full rounded-lg border border-sandDark bg-cream p-3 text-sm" placeholder={OFFER.fields.name} value={form.name} onChange={set("name")} />
            <input className="w-full rounded-lg border border-sandDark bg-cream p-3 text-sm" placeholder={OFFER.fields.phone} inputMode="tel" value={form.phone} onChange={set("phone")} />
            <input className="w-full rounded-lg border border-sandDark bg-cream p-3 text-sm" placeholder={OFFER.fields.city} value={form.city} onChange={set("city")} />
            <input className="w-full rounded-lg border border-sandDark bg-cream p-3 text-sm" placeholder={OFFER.fields.address} value={form.address} onChange={set("address")} />
            <button className="btn-primary disabled:opacity-60" disabled={status === "sending"} onClick={submit}>
              {status === "sending" ? "جارٍ الإرسال…" : OFFER.submit}
            </button>
            {status === "error" && (
              <p className="text-center text-sm text-red-700">صار خطأ — حاول مرة ثانية.</p>
            )}
            <p className="text-center text-xs text-inkSoft">{OFFER.codNote}</p>
          </div>
        )}
      </div>
    </section>
  );
}
