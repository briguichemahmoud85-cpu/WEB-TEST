import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

// استقبال طلب COD. حاليًا يسجّل الطلب في اللوج ويرجع نجاح.
// للإنتاج: اربطه بـ Google Sheets / Telegram bot / أي CRM عبر ORDER_WEBHOOK_URL.
export async function POST(req: Request) {
  const data = await req.json().catch(() => null);
  if (!data?.name || !data?.phone || !data?.city || !data?.address) {
    return NextResponse.json({ ok: false, error: "missing_fields" }, { status: 400 });
  }

  const order = {
    ...data,
    product: "ghafwa-pillow",
    at: new Date().toISOString(),
  };

  const webhook = process.env.ORDER_WEBHOOK_URL;
  if (webhook) {
    try {
      await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order),
      });
    } catch (e) {
      console.error("order webhook failed", e);
    }
  }
  console.log("NEW COD ORDER:", JSON.stringify(order));
  return NextResponse.json({ ok: true });
}
