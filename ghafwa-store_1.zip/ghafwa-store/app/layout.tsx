import type { Metadata } from "next";
import { IBM_Plex_Sans_Arabic, Tajawal } from "next/font/google";
import "./globals.css";
import { BRAND } from "@/lib/site";

const display = Tajawal({ subsets: ["arabic"], weight: ["700", "800", "900"], variable: "--font-display" });
const body = IBM_Plex_Sans_Arabic({ subsets: ["arabic"], weight: ["400", "500", "600"], variable: "--font-body" });

export const metadata: Metadata = {
  title: `${BRAND.name} | ${BRAND.positioning}`,
  description: "وسادة طبية ميموري فوم بتصميم قرن الثور لدعم الرقبة — الدفع عند الاستلام في السعودية.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${display.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}
