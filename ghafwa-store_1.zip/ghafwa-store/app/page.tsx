import Hero from "@/components/Hero";
import TrustBadges from "@/components/TrustBadges";
import Problem from "@/components/Problem";
import Features from "@/components/Features";
import Specs from "@/components/Specs";
import OfferCard from "@/components/OfferCard";
import FAQAccordion from "@/components/FAQAccordion";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Hero />
      <TrustBadges />
      <Problem />
      <Features />
      <Specs />
      <OfferCard />
      <FAQAccordion />
      <Footer />
    </main>
  );
}
