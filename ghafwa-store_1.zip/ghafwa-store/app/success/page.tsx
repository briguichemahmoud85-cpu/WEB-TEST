export const metadata = { robots: { index: false } };

export default function Success() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-sand">
      <div className="card text-center max-w-sm mx-5">
        <p className="font-display font-bold text-2xl mb-2">تم استلام طلبك ✓</p>
        <p className="text-inkSoft">بنتواصل معك على الجوال لتأكيد الطلب قبل الشحن.</p>
      </div>
    </main>
  );
}
